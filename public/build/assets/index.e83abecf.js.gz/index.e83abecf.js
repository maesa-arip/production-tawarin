import{r as c}from"./app.fee021ae.js";let S={data:""},_=t=>typeof window=="object"?((t?t.querySelector("#_goober"):window._goober)||Object.assign((t||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:t||S,H=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,L=/\/\*[^]*?\*\/|  +/g,D=/\n+/g,x=(t,e)=>{let r="",s="",o="";for(let a in t){let n=t[a];a[0]=="@"?a[1]=="i"?r=a+" "+n+";":s+=a[1]=="f"?x(n,a):a+"{"+x(n,a[1]=="k"?"":e)+"}":typeof n=="object"?s+=x(n,e?e.replace(/([^,])+/g,i=>a.replace(/(^:.*)|([^,])+/g,l=>/&/.test(l)?l.replace(/&/g,i):i?i+" "+l:l)):a):n!=null&&(a=/^--/.test(a)?a:a.replace(/[A-Z]/g,"-$&").toLowerCase(),o+=x.p?x.p(a,n):a+":"+n+";")}return r+(e&&o?e+"{"+o+"}":o)+s},y={},T=t=>{if(typeof t=="object"){let e="";for(let r in t)e+=r+T(t[r]);return e}return t},U=(t,e,r,s,o)=>{let a=T(t),n=y[a]||(y[a]=(l=>{let d=0,p=11;for(;d<l.length;)p=101*p+l.charCodeAt(d++)>>>0;return"go"+p})(a));if(!y[n]){let l=a!==t?t:(d=>{let p,f,m=[{}];for(;p=H.exec(d.replace(L,""));)p[4]?m.shift():p[3]?(f=p[3].replace(D," ").trim(),m.unshift(m[0][f]=m[0][f]||{})):m[0][p[1]]=p[2].replace(D," ").trim();return m[0]})(t);y[n]=x(o?{["@keyframes "+n]:l}:l,r?"":"."+n)}let i=r&&y.g?y.g:null;return r&&(y.g=y[n]),((l,d,p,f)=>{f?d.data=d.data.replace(f,l):d.data.indexOf(l)===-1&&(d.data=p?l+d.data:d.data+l)})(y[n],e,s,i),n},R=(t,e,r)=>t.reduce((s,o,a)=>{let n=e[a];if(n&&n.call){let i=n(r),l=i&&i.props&&i.props.className||/^go/.test(i)&&i;n=l?"."+l:i&&typeof i=="object"?i.props?"":x(i,""):i===!1?"":i}return s+o+(n==null?"":n)},"");function A(t){let e=this||{},r=t.call?t(e.p):t;return U(r.unshift?r.raw?R(r,[].slice.call(arguments,1),e.p):r.reduce((s,o)=>Object.assign(s,o&&o.call?o(e.p):o),{}):r,_(e.target),e.g,e.o,e.k)}let M,I,N;A.bind({g:1});let h=A.bind({k:1});function Y(t,e,r,s){x.p=e,M=t,I=r,N=s}function b(t,e){let r=this||{};return function(){let s=arguments;function o(a,n){let i=Object.assign({},a),l=i.className||o.className;r.p=Object.assign({theme:I&&I()},i),r.o=/ *go\d+/.test(l),i.className=A.apply(r,s)+(l?" "+l:""),e&&(i.ref=n);let d=t;return t[0]&&(d=i.as||t,delete i.as),N&&d[0]&&N(i),M(d,i)}return e?e(o):o}}var Z=t=>typeof t=="function",j=(t,e)=>Z(t)?t(e):t,q=(()=>{let t=0;return()=>(++t).toString()})(),F=(()=>{let t;return()=>{if(t===void 0&&typeof window<"u"){let e=matchMedia("(prefers-reduced-motion: reduce)");t=!e||e.matches}return t}})(),B=20,$=new Map,G=1e3,P=t=>{if($.has(t))return;let e=setTimeout(()=>{$.delete(t),v({type:4,toastId:t})},G);$.set(t,e)},J=t=>{let e=$.get(t);e&&clearTimeout(e)},z=(t,e)=>{switch(e.type){case 0:return{...t,toasts:[e.toast,...t.toasts].slice(0,B)};case 1:return e.toast.id&&J(e.toast.id),{...t,toasts:t.toasts.map(a=>a.id===e.toast.id?{...a,...e.toast}:a)};case 2:let{toast:r}=e;return t.toasts.find(a=>a.id===r.id)?z(t,{type:1,toast:r}):z(t,{type:0,toast:r});case 3:let{toastId:s}=e;return s?P(s):t.toasts.forEach(a=>{P(a.id)}),{...t,toasts:t.toasts.map(a=>a.id===s||s===void 0?{...a,visible:!1}:a)};case 4:return e.toastId===void 0?{...t,toasts:[]}:{...t,toasts:t.toasts.filter(a=>a.id!==e.toastId)};case 5:return{...t,pausedAt:e.time};case 6:let o=e.time-(t.pausedAt||0);return{...t,pausedAt:void 0,toasts:t.toasts.map(a=>({...a,pauseDuration:a.pauseDuration+o}))}}},k=[],O={toasts:[],pausedAt:void 0},v=t=>{O=z(O,t),k.forEach(e=>{e(O)})},Q={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},V=(t={})=>{let[e,r]=c.exports.useState(O);c.exports.useEffect(()=>(k.push(r),()=>{let o=k.indexOf(r);o>-1&&k.splice(o,1)}),[e]);let s=e.toasts.map(o=>{var a,n;return{...t,...t[o.type],...o,duration:o.duration||((a=t[o.type])==null?void 0:a.duration)||(t==null?void 0:t.duration)||Q[o.type],style:{...t.style,...(n=t[o.type])==null?void 0:n.style,...o.style}}});return{...e,toasts:s}},W=(t,e="blank",r)=>({createdAt:Date.now(),visible:!0,type:e,ariaProps:{role:"status","aria-live":"polite"},message:t,pauseDuration:0,...r,id:(r==null?void 0:r.id)||q()}),w=t=>(e,r)=>{let s=W(e,t,r);return v({type:2,toast:s}),s.id},u=(t,e)=>w("blank")(t,e);u.error=w("error");u.success=w("success");u.loading=w("loading");u.custom=w("custom");u.dismiss=t=>{v({type:3,toastId:t})};u.remove=t=>v({type:4,toastId:t});u.promise=(t,e,r)=>{let s=u.loading(e.loading,{...r,...r==null?void 0:r.loading});return t.then(o=>(u.success(j(e.success,o),{id:s,...r,...r==null?void 0:r.success}),o)).catch(o=>{u.error(j(e.error,o),{id:s,...r,...r==null?void 0:r.error})}),t};var X=(t,e)=>{v({type:1,toast:{id:t,height:e}})},K=()=>{v({type:5,time:Date.now()})},tt=t=>{let{toasts:e,pausedAt:r}=V(t);c.exports.useEffect(()=>{if(r)return;let a=Date.now(),n=e.map(i=>{if(i.duration===1/0)return;let l=(i.duration||0)+i.pauseDuration-(a-i.createdAt);if(l<0){i.visible&&u.dismiss(i.id);return}return setTimeout(()=>u.dismiss(i.id),l)});return()=>{n.forEach(i=>i&&clearTimeout(i))}},[e,r]);let s=c.exports.useCallback(()=>{r&&v({type:6,time:Date.now()})},[r]),o=c.exports.useCallback((a,n)=>{let{reverseOrder:i=!1,gutter:l=8,defaultPosition:d}=n||{},p=e.filter(g=>(g.position||d)===(a.position||d)&&g.height),f=p.findIndex(g=>g.id===a.id),m=p.filter((g,C)=>C<f&&g.visible).length;return p.filter(g=>g.visible).slice(...i?[m+1]:[0,m]).reduce((g,C)=>g+(C.height||0)+l,0)},[e]);return{toasts:e,handlers:{updateHeight:X,startPause:K,endPause:s,calculateOffset:o}}},et=h`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,rt=h`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,at=h`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,ot=b("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${t=>t.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${et} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${rt} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${t=>t.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${at} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,st=h`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,it=b("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${t=>t.secondary||"#e0e0e0"};
  border-right-color: ${t=>t.primary||"#616161"};
  animation: ${st} 1s linear infinite;
`,nt=h`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,lt=h`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,dt=b("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${t=>t.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${nt} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${lt} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${t=>t.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,ct=b("div")`
  position: absolute;
`,pt=b("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,ut=h`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,mt=b("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${ut} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,ft=({toast:t})=>{let{icon:e,type:r,iconTheme:s}=t;return e!==void 0?typeof e=="string"?c.exports.createElement(mt,null,e):e:r==="blank"?null:c.exports.createElement(pt,null,c.exports.createElement(it,{...s}),r!=="loading"&&c.exports.createElement(ct,null,r==="error"?c.exports.createElement(ot,{...s}):c.exports.createElement(dt,{...s})))},gt=t=>`
0% {transform: translate3d(0,${t*-200}%,0) scale(.6); opacity:.5;}
100% {transform: translate3d(0,0,0) scale(1); opacity:1;}
`,yt=t=>`
0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}
100% {transform: translate3d(0,${t*-150}%,-1px) scale(.6); opacity:0;}
`,ht="0%{opacity:0;} 100%{opacity:1;}",xt="0%{opacity:1;} 100%{opacity:0;}",bt=b("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,vt=b("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,wt=(t,e)=>{let r=t.includes("top")?1:-1,[s,o]=F()?[ht,xt]:[gt(r),yt(r)];return{animation:e?`${h(s)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${h(o)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}},Et=c.exports.memo(({toast:t,position:e,style:r,children:s})=>{let o=t.height?wt(t.position||e||"top-center",t.visible):{opacity:0},a=c.exports.createElement(ft,{toast:t}),n=c.exports.createElement(vt,{...t.ariaProps},j(t.message,t));return c.exports.createElement(bt,{className:t.className,style:{...o,...r,...t.style}},typeof s=="function"?s({icon:a,message:n}):c.exports.createElement(c.exports.Fragment,null,a,n))});Y(c.exports.createElement);var $t=({id:t,className:e,style:r,onHeightUpdate:s,children:o})=>{let a=c.exports.useCallback(n=>{if(n){let i=()=>{let l=n.getBoundingClientRect().height;s(t,l)};i(),new MutationObserver(i).observe(n,{subtree:!0,childList:!0,characterData:!0})}},[t,s]);return c.exports.createElement("div",{ref:a,className:e,style:r},o)},kt=(t,e)=>{let r=t.includes("top"),s=r?{top:0}:{bottom:0},o=t.includes("center")?{justifyContent:"center"}:t.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:F()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${e*(r?1:-1)}px)`,...s,...o}},Ot=A`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,E=16,At=({reverseOrder:t,position:e="top-center",toastOptions:r,gutter:s,children:o,containerStyle:a,containerClassName:n})=>{let{toasts:i,handlers:l}=tt(r);return c.exports.createElement("div",{style:{position:"fixed",zIndex:9999,top:E,left:E,right:E,bottom:E,pointerEvents:"none",...a},className:n,onMouseEnter:l.startPause,onMouseLeave:l.endPause},i.map(d=>{let p=d.position||e,f=l.calculateOffset(d,{reverseOrder:t,gutter:s,defaultPosition:e}),m=kt(p,f);return c.exports.createElement($t,{id:d.id,key:d.id,onHeightUpdate:l.updateHeight,className:d.visible?Ot:"",style:m},d.type==="custom"?j(d.message,d):o?o(d):c.exports.createElement(Et,{toast:d,position:p}))}))},Ct=u;export{At as I,Ct as _,u as n};
